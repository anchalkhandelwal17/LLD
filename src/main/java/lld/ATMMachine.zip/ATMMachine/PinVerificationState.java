package lld.ATMMachine;

public class PinVerificationState implements State{
    @Override
    public void idle(ATMMachine atmMachine) {

    }

    @Override
    public void cardInserted(ATMMachine atmMachine) {

    }

    @Override
    public void selectOption(ATMMachine atmMachine, TransactionType transactionType) {

    }

    @Override
    public void pinVerification(ATMMachine atmMachine) {
        if(atmMachine.getBankService().authenticate(atmMachine.getInsertedPin())){
            atmMachine.setAtmMachineState(new SelectOptionState());
        }
        atmMachine.setAtmMachineState(new IdleState());
    }
}
