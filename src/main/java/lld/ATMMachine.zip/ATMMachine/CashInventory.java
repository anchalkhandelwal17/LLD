package lld.ATMMachine;

import java.util.Map;

public class CashInventory {
    Map<Denomination, Integer> notes;
}
