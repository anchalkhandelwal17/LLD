package lld.ATMMachine;

public class Account {
    // balance, accountNumber
    private int accountNumber;
    private double balance;
    private String accountHolderName;
    private AccountType accountType;

}
