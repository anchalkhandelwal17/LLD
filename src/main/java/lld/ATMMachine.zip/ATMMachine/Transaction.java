package lld.ATMMachine;

public interface Transaction {
    void execute();
}

class WithdrawTransaction implements Transaction {

    @Override
    public void execute() {
        System.out.println("");
    }
}

class DepositTransaction implements Transaction {

    @Override
    public void execute() {
        System.out.println("");
    }
}

class BalanceInquiryTransaction implements Transaction {

    @Override
    public void execute() {
        System.out.println("");
    }
}
