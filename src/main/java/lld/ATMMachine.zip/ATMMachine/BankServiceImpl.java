package lld.ATMMachine;

public class BankServiceImpl implements BankService{
    @Override
    public boolean authenticate(int pin) {
        return false;
    }

    @Override
    public void withdraw() {

    }

    @Override
    public double getBalance() {
        return 0;
    }
}
